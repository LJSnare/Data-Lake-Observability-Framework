**14의 반례·부분 성공·승인 판단 절차를 먼저 적용한다.** 여기의 API 상세는 Claude에게 새로운 자동 쓰기 권한을 부여하지 않는다.

## 역할 경계 (v5.3.3)
이 문서의 “실행”은 Claude가 현재 세션에서 승인된 도구로 작업할 때 따르는 **절차**다. 별도 프로그램·스케줄러 개발을 전제하지 않는다. 오프라인 계획기에서 `CREATE_PROPOSAL`이 나와도 승인된 실제 쓰기 권한을 뜻하지 않는다. 기존 페이지 재사용·수정 시 루트 하위 조상 관계를 검증해야 한다.


## 실행 선행 조건
Confluence 쓰기 전 `ROOT_CONFIRMED`와 `TREE_SCOPE_APPROVED` 둘 다 확인한다. `WAITING_FOR_ROOT_CONFIRMATION`, `ROOT_INVALID`, 위임 범위 밖은 쓰기 중단. 승인된 루트 하위의 반복 저위험 변경만 재승인 생략. `13_CONFLUENCE_ROOT_DELEGATION.md` 우선.

# 12. 실행 자동화·동기화·실패 복구 계약 (규범)

## 결론: 자동화는 “계획 + 실제 도구 + 재실행 안전 + 검증”의 조합
문서가 자동화 기능을 제공하지는 않는다. 내부 Claude에 Grafana/Confluence 조회·쓰기 도구가 연결되어야 실제 게시가 가능하다. 본 패키지는 **운영 알고리즘과 오프라인 검증기**를 제공한다. `qa/reconciler.py`는 의도적으로 네트워크·쓰기 기능이 없는 안전한 계획 엔진이다. 실제 회사 API 연결은 권한 확인 후 별도 어댑터가 필요하다.

## 단계별 상태기계
`DISCOVERED → PLANNED → AWAITING_APPROVAL → APPROVED → APPLYING → VERIFYING → VERIFIED`.
`BLOCKED`(권한/연결 부족), `CONFLICT`(사람이 수정/동일성 모호), `PARTIAL`(일부 성공), `FAILED`(실패), `DEFERRED`(추후)는 종료 상태로 명확히 보고한다. `VERIFIED`는 **사내 읽기 재조회 증거**가 있을 때만 허용. `APPROVED` 텍스트 하나만으로 실행 권한이 성립하지 않는다.

## 입력/원본
- 사용자 입력 최소: Grafana 폴더/대시보드 또는 Confluence 루트 중 하나. 나머지는 권한 내 검색으로 발견. **게시 시에는 실제 Grafana 범위 + Confluence 루트 + 접근권한이 모두 확인**되어야 한다.
- `observed_grafana.json`: 폴더 UID, 대시보드 UID, 패널 ID, 의미상 metric_key, 패널 제목, 중요도, Grafana URL, 최종 조회 시각. **실제 조회값만** 사용. Grafana 패널 ID는 편집/복제 시 바뀔 수 있어 영속 키가 아니다.
- `observed_confluence.json`: 루트 ID, page ID, parent ID, 제목, 버전, 마지막 편집자, 본문/관리 구역 해시, 제한, 링크. 하위 트리는 페이지네이션을 끝까지 조회; 부분 조회는 `INCOMPLETE_DISCOVERY`.
- `registry.json`: 회사가 관리하는 고유 매핑. `logical_key`는 `dashboard:<dashboard_uid>` 또는 `panel:<dashboard_uid>:<metric_key>` 등으로 만들되 metric_key가 실제로 안정적인지 검증한다. 수동 문서·동명이인·기존 링크는 무조건 덮어쓰지 않는다.

## 오프라인 계획 알고리즘
1. 읽기 전용으로 두 시스템 전체 범위를 확인. API 실패·페이지네이션 누락·권한 제한이면 누락 페이지를 **없는 것으로 판단하지 않는다**.
2. 매핑 레지스트리 page ID와 실제 페이지를 대조한다. ID가 없으면 기존 문서에서 UID/링크/명시적 키를 찾는다. 제목만 같으면 `REVIEW`.
3. Grafana 폴더→대시보드→패널을 분리한다. 중요 패널만 별도 페이지, 나머지는 상위 문서 섹션으로 제안한다. 이름 바뀐 기존 패널은 동일 키로 갱신.
4. `REUSE`, `CREATE`, `UPDATE`, `REVIEW`, `SKIP` 계획과 부모 의존성, 문서 diff, 근거, 변경 규모를 작성한다. 읽기 전용 단계에서 문서 쓰기 금지.
5. 한 번의 승인 카드로 루트·범위·생성/수정 수·위험·검증·복구·담당자를 제시한다. 사용자가 승인한 범위 밖은 재승인.
6. **쓰기 직전 재조회**: 루트/부모/대상 버전, 페이지 제한, 승인 범위, 동일 키 중복, 최신 수정 여부. 어긋나면 중단.
7. 부모→자식 순으로 작성; 각 성공 응답의 실제 page ID/version을 회사 승인 저장소에 즉시 기록. 재시도 시 먼저 조회해 동일 작업 여부 확인. 불명확한 타임아웃 직후 **무조건 POST 재시도 금지**.
8. 게시 후 별도 읽기 권한/브라우저로 링크, 본문, 부모관계, 권한, 버전을 확인. 실패는 `PARTIAL`/`NOT_VERIFIED`로 남기고 복구안 제시.

## 사람 작성 문서 보존
기존 문서는 본문 전체 교체가 기본값이 아니다. **Claude 관리 섹션만 수정**하거나 변경 diff를 사람에게 보여준다. 이전 버전 해시와 현재 해시가 다르면 충돌로 중단한다. Cloud 페이지 업데이트 시 버전 번호가 필수이며, 드래프트 병합/대체 위험이 있어 미리보기 및 충돌 검사가 필요하다. Data Center는 별도 API 계약을 확인한다. 보안상 링크에 검색어·사용자 ID·토큰을 넣지 않는다.

## 작업 종료 문서 동기화
대시보드 신규/패널 중요도/산식/Runbook/링크가 바뀌면 `DOC_IMPACT=NEEDED`와 최소 영향 범위를 산출한다. 색상/간격 등 운영 의미 변화가 없으면 `NONE`으로 조용히 종료. 판단 불가면 `UNKNOWN`으로 사유를 보고. `NEEDED`이면서 승인 범위 내라면 계획→게시→재조회, 범위 밖이면 한 번에 묶어 승인 요청.

## 주기적 점검 — 두 가지 별개 동작
- 기본: 작업 종료 시 이벤트 기반 문서 영향 검사. 추가 스케줄러 필요 없음.
- 선택: 주간/월간 읽기 전용 drift 탐지. **사내 실행 수단과 사용자 승인이 있을 때만** 활성화. 실제 동작하지 않으면 `NOT_SCHEDULED`.
- drift 분류: `MISSING`, `STALE`, `ORPHAN`, `DUPLICATE`, `CONFLICT`, `PERMISSION`, `UNKNOWN`. 자동 삭제·자동 공개 범위 확대 금지. 검출 시 변경 계획을 묶어 제시.
- 정기 점검이 실제 Grafana 대시보드 변경을 감지하려면 전체 대상 목록에 대한 읽기 권한과 안정적인 매핑이 필요하다.

## 실패 처리 / 복구
- `401/403`: 권한/인증 점검 후 중단. `404`: 권한 은폐 가능성도 있어 삭제로 단정하지 않음.
- `409`/버전 충돌: 재조회 후 diff; 수동 병합/승인. 자동 덮어쓰기 금지.
- `429`/`5xx`: 서버가 제시한 지연을 존중하고 제한된 횟수만 재시도; **POST 결과가 불확실하면 조회로 중복 확인부터**.
- 부분 생성: 이미 성공한 page ID를 기록, 재실행은 그 페이지를 재사용. 임의 일괄 삭제 롤백 금지.
- 문서와 Grafana가 불일치하면 링크를 검증 전으로 표시하고, 해당 배포의 운영 상태를 `PARTIAL`로 보고.

## 필수 운영 인수 테스트 (내부 실행 전부 미완료)
1. 동일 작업 2회 수행해 페이지 수/매핑 불변.
2. 생성 API 타임아웃 뒤 이미 생성된 페이지를 조회하여 중복 방지.
3. 부모 페이지 이동/삭제/권한 변경 직후 중단.
4. 사용자 편집 후 버전 충돌에서 본문 보존.
5. 하위 페이지 목록 일부만 조회된 경우 신규 생성 중단.
6. 기존 같은 제목의 수동 문서 발견 시 자동 덮어쓰기 금지.
7. 승인 범위 밖 추가 패널/루트 이동 요청 차단.
8. 링크 권한 없는 운영자 계정에서 검증 실패 표시.
9. 문서 영향 없는 패널 색상 변경 시 게시 0건.
10. 스케줄러 없는 환경에서 `NOT_SCHEDULED`.

## 공식 문서 근거 (설치 버전별 재확인)
- Grafana dashboard API: https://grafana.com/docs/grafana/latest/developer-resources/api-reference/http-api/dashboard/
- Confluence Cloud Page v2: https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-page/
- OpenSearch terms: https://docs.opensearch.org/latest/aggregations/bucket/terms/
- OpenSearch cardinality: https://docs.opensearch.org/latest/aggregations/metric/cardinality/

## 삭제 금지·작업 외 변경 금지 복구 경계
Confluence 삭제·아카이브·이동 API 호출 및 Grafana 대시보드 삭제·비대상 변경을 자동 복구·정리 단계에서 사용하지 않는다. `DELETE`라는 이름의 기존 작업이 발견되면 쓰기를 중단하고 16의 `[삭제 대상]` 제목 표시 후보로 전환한다. Grafana 롤백은 다른 사람의 변경을 포함한 전체 JSON 덮어쓰기가 아니라 승인된 필드의 최소 변경으로 수행한다. 실패 시 재조회→현재 버전 대조→안전한 재계획, 확인 불가 시 보류.


## v6.3 공통 상태 매핑
본 문서의 `DISCOVERED/PLANNED/AWAITING_APPROVAL/APPROVED/APPLYING/VERIFYING/VERIFIED`는 단계별 기술 이벤트를 설명하는 레거시 상태명이다. **최종 작업 상태의 단일 기준은 `21_END_TO_END_PROCESS_GATES.md`**의 전체 상태이며 `KPI_VERIFIED`, `GRAFANA_VERIFIED`, `CONFLUENCE_VERIFIED`는 증거 플래그다. `APPROVED` 이벤트는 18 승인원장 확인 전 쓰기 허가가 아니다. 재시도 전 승인 철회·계약·현재 버전을 재조회한다.
