# v5.4.1 2차 반례 감사 (2026-10-15)

## 재현·수정한 추가 결함
1. `qa/reconciler.py`: 대시보드 항목을 dict인지 확인하기 전에 `.get()`을 호출해 malformed snapshot에서 예외가 발생했다. 사전 타입 검증으로 변경.
2. 패널의 `needs_runbook`이 문자열/숫자여도 truthy 값으로 받아들여 운영가이드가 생성 계획에 포함될 수 있었다. boolean만 허용하도록 수정.
3. `dashboards` 또는 `panels` 필드가 누락되면 빈 목록으로 간주해 누락을 정상으로 오인할 수 있었다. 스냅샷 필수 필드 누락 시 BLOCKED로 변경.
4. 대표 루트 페이지 ID를 기존 운영가이드로 매핑하면 루트 자체를 REUSE/UPDATE 대상으로 판단할 수 있었다. 루트 자체는 수정 대상에서 제외.
5. 레지스트리 값이 공백만 있어도 통과할 수 있었다. 공백 문자열 차단.

## 실행한 검증
- `qa/test_second_pass.py`: 325개 합성 검사(무작위 시드 고정 오염 입력 300개 포함)
- `qa/test_adversarial.py`: 25개
- `qa/test_reconciler.py`: 18개
- `qa/check_tree_plan.py`: 7개
- `qa/test_root_gate.py`: 8개
- `qa/check_package.py`: 문서, 파일 목록, 해시 검사
- ZIP CRC/파일 무결성 검사
이 검사는 코드의 오프라인 판단을 확인할 뿐 Claude의 실제 지시 준수나 사내 API 연동을 증명하지 않는다.

## 검증하지 못한 항목 (중요)
실제 사내 Confluence 권한, 사람이 동시에 수정하는 상황, API POST 타임아웃과 중복 생성, 페이지 이동, 세션 간 승인 보존, 실제 Grafana/OpenSearch KPI 독립 대조는 모두 NOT_TESTED. `complete=true`는 입력 선언이며 실제 탐색 완전성의 증거가 아니다. 따라서 실제 공유 게시 및 운영 배포 자동화는 별도의 제한된 파일럿 검증이 필요하다.

## 판정
오프라인 계획기 입력 방어 및 루트 보호 개선 PASS. 운영 전체의 완전성/무결성 인증은 불가. 추가 위험 발견 시 반례를 재현하고 검증 기록을 남긴 후에만 수정·버전 갱신한다.
