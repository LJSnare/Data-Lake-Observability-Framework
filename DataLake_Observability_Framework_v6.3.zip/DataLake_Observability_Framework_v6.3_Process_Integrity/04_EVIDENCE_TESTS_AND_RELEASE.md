# 04. 검증·출시 게이트 (언어 중립)

## 검증 수준

| 수준 | 증거 | 주장 가능한 범위 |
|---|---|---|
| L0 | 문서 링크·JSON·참조·해시 정적 검사 | 전달 파일 구조 |
| L1 | 독립 기대값을 가진 합성 데이터/반례 | 계산 규칙 예시 |
| L2 | 내부 실제 로그 표본·필드 의미 | 해당 표본 의미 |
| L3 | 실제 OpenSearch 쿼리 vs 독립 대조 | 특정 시간·필터 KPI 정확성 |
| L4 | 실제 Grafana·Confluence 클릭·SSO·권한 | 해당 사용자 경로 |
| L5 | 배포 후 운영자 과제·지연·오류 관찰 | 제한된 운영 효과 |

Python/Java/JS 언어는 무관. **테스트 코드와 기대값이 동일한 잘못된 가정에서 만들어졌다면 통과해도 신뢰할 수 없다.** 실제 로그 의미·독립 oracle·부정 사례·현장 관찰을 조합한다.

## 릴리스 차단 (BLOCK)

- 중요 KPI가 `PROPOSED`/`UNKNOWN`이거나 실제 분자/분모 불일치.
- React 계측 전인데 UI 퍼널·클릭률이 사실인 것처럼 표시.
- 수집 실패를 0으로 표시, TOP N을 전체로 오인, 근사 수치를 정확하다고 주장.
- 개인정보·권한·SSO/Runbook 링크 확인 실패, 승인 증거 없음, 운영 백업/롤백 없음.
- OpenSearch 쿼리 timeout/부분 shard 실패/과도한 부하, Grafana 대시보드 프로비저닝 덮어쓰기 위험 미해결.

## 실환경 검증 기록 (민감정보는 사내에만)

`test_id / target_version / query_or_dashboard_ref / start_end_timezone / filters / independent_oracle / observed / delta / negative_case / executor / timestamp / PASS|FAIL|NOT_TESTED|BLOCKED / evidence_location`. 지표는 기간·필터·권한·인덱스 범위를 동일하게 비교.

## 반례 묶음

중복·충돌 request ID, 요청 ID 누락, 전체 결과 수 vs 페이지 건수, null/zero/NO_DATA, 타임존 경계, late arrival/reindex, `terms` 누락, `cardinality` 근사, 대시보드 변수 유출, 403/404/SSO, Confluence 버전 충돌, React effect 중복, 종속 필터 자동 변경, 미승인 쓰기, 롤백 실패. `qa/ACCEPTANCE_MATRIX.tsv`는 **검사할 시나리오 목록**이며 통과 보고서가 아니다.

## 배포 전후

배포 전 소유권·백업·변경 diff·승인·권한·비용·쿼리 성능 확인. 배포 후 수치·링크·성능·접근성 확인; 실패 시 즉시 중단·복원. **사내 반입 가능**과 **운영 배포 승인**을 혼동하지 않는다.

## v5.2 트리 계획 추가 정적 검사
`python qa/check_tree_plan.py`는 트리 부모 선행 순서·중복 키·승인 누락·허위 성공 등 합성 계획의 오류 탐지 여부만 검사한다. **Confluence API 생성·권한·사용자 브라우저 접근 검증이 아니다.** 내부에서는 실제 대표 루트 1개를 대상으로 읽기 조사 → 승인된 소규모 트리 게시 → 재실행 중복 0건 → 링크·권한 확인 → 변경 감지의 통합 검증이 필요하다.

> 실행·동기화·재시도·복구의 안전 조건은 `12_AUTOMATION_EXECUTION_AND_RECOVERY.md`를 우선 적용한다.

## v5.6 추가 필수 검증
`qa/test_workspace_scope.py`는 범위 가드의 **합성** 검증이며 실제 내부 Claude의 행동·Grafana/Confluence 권한을 강제하지 않는다. 실제 적용 시 지정 루트/폴더 UID, 허용된 작업물 ID, 기존 연결, 비대상 diff, `[삭제 대상]` 마킹/재시도, TOC 링크 영향, 동시 수정과 API 타임아웃을 별도로 검증한다. 사내 실연동 검증 전에는 `LIVE_NOT_TESTED`를 유지한다.
