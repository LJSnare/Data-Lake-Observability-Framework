# 02. 로그와 지표의 진실성

## 계약의 최소 필드

`metric_id, display_name_ko, purpose, event_source, logical_event, population, numerator, denominator, dedup_key_and_policy, timestamp_semantics, timezone, filters, missing_data_behavior, latency_or_late_data, query_evidence, owner, status, last_validated_at`. 숫자 지표의 방향과 임계치는 근거가 없으면 `UNDEFINED`.

**예: 검색 결과 없음 비율(설계 후보)** = 검색 완료 논리 요청 중 **전체 결과 수 0**인 요청 / 같은 기간 검색 완료 논리 요청. `request_id` 존재·의미, 완료 이벤트의 정의, 페이지 건수와 전체 결과 건수 구분, 중복/재시도/필터 변경을 검증하기 전에는 `PROPOSED`로 둔다. OpenSearch `doc_count`가 요청 수와 같다고 가정 금지. 중복 요청 간 상충 값은 임의로 최신 값 선택하지 않고 `CONFLICT`로 분리한다.

| 값/상태 | 뜻 | 표시 원칙 |
|---|---|---|
| 0 | 유효한 분모·완전한 수집에서 실제 0 | `0` 표시 |
| NO_DATA | 유효 관측 대상이 0개 | `데이터 없음` |
| UNKNOWN | 필드 의미·계산 검증 부족 | `검증 중` |
| COLLECTION_ERROR | 파이프라인 실패·부분 수집 | `수집 오류` |
| NOT_INSTRUMENTED | 이벤트 자체가 없음 | `미계측` |
| PARTIAL / PROVISIONAL | 지연/재처리/샘플링 영향 | 잠정치 표시 |

## OpenSearch 검증 포인트

- `terms` TOP N 버킷의 합을 전체로 사용 금지. `sum_other_doc_count`, 오차, `shard_size`, 결과 수 제한 확인. 전체 고유 키가 필요하면 `composite` + `after_key` 페이지네이션 또는 검증된 다른 정확한 방법을 평가(비용 주의).
- `cardinality`는 근사; 일별 고유 사용자 합은 기간 고유 사용자와 다름. 필요 정확도/비용을 명시.
- `hits.total` 관계값, `track_total_hits`, 쿼리 실패·timeout·shard 실패를 검토. 시간은 동일한 `[start,end)` 범위, timezone, date histogram fixed/calendar interval, DST를 비교.
- 검색 API 응답 로그와 실제 UI 검색 제출은 다르다. 현재 React 사용자 이벤트가 없다면 클릭률·이탈률·탭 사용률·필터 사용률을 만들지 않는다.
- 개인정보/검색어/사번/파일명/원본 URL을 기본 패널이나 링크 변수로 노출하지 않는다. 필드 마스킹·접근제어·보존 정책을 확인.

## 통합검색 업무 흐름과 구분

홈 검색 → 결과 페이지 → 약 6개 필터(종속·독립) → 결과 그리드 → 자산 상세 탭(개요/파일/계보 등). 각 단계의 **서버 이벤트 관측**과 **사용자 행동 관측**을 분리. DRM 업로드/복호화/실패/우회는 단계별 상태·보안 정책 확인 후 별도 계약. 카탈로그/AI 지표도 출처·품질·비용이 다르면 대시보드 분리.

## 상태

지표 성숙도 `PROPOSED → SOURCE_VERIFIED → RECONCILED → APPROVED`, 검증 결과 `PASS/FAIL/NOT_TESTED/NOT_APPLICABLE`는 별개. 근거 없는 SLO 숫자·임계치 발명 금지.


## v6.3 강제 게이트
실제 KPI 패널 게시 전 `21_END_TO_END_PROCESS_GATES.md`의 `KPI_VERIFIED` 필수 조건을 충족해야 한다. 스키마·계약·기간·시간대 변경 시 기존 검증을 무효화한다. 일반 소개 문서와 패널 가이드의 게시 조건은 다르다.
