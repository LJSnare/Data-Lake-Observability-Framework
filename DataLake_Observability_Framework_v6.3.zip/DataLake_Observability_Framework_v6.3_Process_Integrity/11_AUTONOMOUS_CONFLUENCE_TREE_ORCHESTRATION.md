## 대표 페이지 경계의 강제 확인 (v5.3.3)
제목·관리 키가 일치하더라도 **실제 Confluence 조상 페이지를 끝까지 확인하여 지정 루트의 하위인지 검증**하기 전에는 재사용/갱신하지 않는다. 부모 관계 조회가 불완전하면 `REVIEW`/`BLOCKED`이며 다른 Space·부서 문서를 수정하지 않는다. 새 페이지는 루트 아래의 승인된 부모에만 제안한다. 트리 계획기 출력은 승인이나 쓰기 권한을 부여하지 않는다.


## 중요: 루트 선택은 자동화하지 않는다
기존 후보를 검색·추천하는 것은 가능하지만 **사용자 확인 없이 루트 확정·게시 금지**. 사용자가 최초 상위 페이지를 지정한 뒤에만 그 아래 하위 트리를 자율 설계한다. 루트 지정과 트리 쓰기 승인도 별도다. 자세한 정책은 `13_CONFLUENCE_ROOT_DELEGATION.md`.

# 11. Confluence 하위 트리 자율 설계·생성·유지관리 (규범)

## 목적 및 시스템 경계
사용자는 **회사에서 승인한 대표 Confluence 페이지 또는 기존 상위 페이지 하나**만 지정할 수 있다. Claude는 해당 루트 아래의 대시보드/패널 운영가이드 구조를 **스스로 조사·제안·생성·유지**한다. 사용자가 하위 페이지를 일일이 만들거나 제목·ID를 제공하도록 요구하지 않는다. 최초 루트 후보는 검색해 제안할 수 있으나 사용자가 직접 지정·확인해야 한다. 회사 권한 정책상 상위 페이지를 사용자가 직접 생성해야 할 때만 최소한의 조치를 요청한다.

**구별:** Grafana의 folder는 대시보드의 보관·권한 단위, dashboard는 panel의 컨테이너이다. **Grafana 패널은 폴더의 자식이 아니다.** 아래 트리는 Confluence *페이지 계층*이다. Grafana 폴더를 받았으면 API/허용된 UI로 하위 대시보드 및 패널을 조사하여 Confluence 트리 후보를 만든다. Confluence 루트와 Grafana 폴더는 서로 다른 식별자·권한 체계이며 각각 확인한다.

## 1. 최소 사용자 입력과 발견 우선순위
1. 이미 승인된 `confluence_root_page_id`가 있으면 재사용한다. 없으면 운영가이드 게시가 필요한 시점에 사용자에게 대표 페이지 지정을 요청한다. 읽기 권한으로 후보를 찾을 수 있으면 추천하되 직접 확정하지 않는다.
2. 사용자가 선택한 **Confluence 상위 페이지 URL 또는 ID**를 요청한다. Space만 제공된 경우 실제 대표 페이지를 추가 확인한다. 사용자가 루트 하나를 지정하면 그 아래 전체 트리는 Claude가 책임진다.
3. Grafana `folder_uid` 또는 특정 `dashboard_uid`가 있으면 이를 출발점으로 삼는다. 없으면 권한 내 관련 검색 대시보드 후보를 탐색해 제시한다. **Confluence 루트와 Grafana 폴더 중 어느 하나만 제공돼도 읽기 전용 계획 수립은 가능**하지만 쓰기에는 실제 대상 확인이 필요하다.
4. Cloud/Data Center, API 사용 가능 여부, 서비스 계정, 생성/수정 권한, 페이지 제한/상속, 회사 문서 표준을 먼저 확인한다. 도구가 없으면 계획과 한국어 초안을 제공하고 `BLOCKED_NO_WRITE_CAPABILITY`로 끝낸다. 승인했다고 해서 연결되지 않은 API를 사용할 수 있는 것은 아니다.

## 2. 기본 트리: 실제 현황에 맞춰 조정
```text
[사용자 지정/승인된 Confluence 대표 페이지] (변경 금지)
├── 00. 운영 대시보드 안내 (범위, 담당, 접근권한, 최근 검증)
├── 01. 통합검색 대시보드 (Grafana dashboard UID, 설명, 패널 색인)
│   ├── 01. 검색건수 (정의·산식·근거·진단·조치·상세 링크)
│   ├── 02. 검색오류 (오류 분류·영향·확인·조치·에스컬레이션)
│   └── [보조 패널은 독립 문서 대신 대시보드 페이지의 섹션]
├── 02. 검색 품질 대시보드 (실제 존재/승인 시)
├── 03. 자산 상세 대시보드 (실제 존재/승인 시)
├── 04. DRM 운영 대시보드 (실제 존재/승인 시)
└── 90. 운영 표준·변경 이력 (원본 정책에 따라 링크/게시)
```
**예시 구조이지 생성 지시가 아니다.** 실제 존재하지 않는 대시보드·패널의 페이지를 미리 만들어 완료했다고 하지 않는다. `01/02` 번호는 표시용이며 식별자로 사용하지 않는다. 팀 관례가 있으면 따른다. 대시보드 이름이 바뀌어도 UID 매핑으로 재사용한다.

## 3. 독립 패널 문서 생성 기준
독립 문서 권장: 운영자 조치가 필요한 오류/핵심 KPI, 산식·한계가 복잡한 지표, 장애 대응 Runbook, 반복 참조되는 가이드. 상위 페이지 내 섹션 권장: 단순 추세·보조 표·장식 패널, 동일 조치를 공유하는 패널. 중복된 설명은 하나의 Runbook에 두고 여러 패널에서 참조한다. **모든 패널에 무조건 페이지를 만들지 않는다.** 운영자 탐색 비용과 페이지 수를 함께 고려한다.

## 4. Claude의 트리 변경 계획 생성 (읽기 전용)
- 실제 Grafana `folder_uid → dashboard_uid → panel_id/panel_key`를 읽고, 각 패널의 운영 중요도와 기존 Confluence 문서를 조사한다.
- 기존 루트 아래 **직계 자식만이 아니라 관련 하위 트리**를 조사한다. 동명 페이지·수동 작성 문서·페이지 이동·담당자·수정 시각을 확인한다.
- `CREATE_PARENT`, `CREATE_CHILD`, `UPDATE`, `LINK_ONLY`, `REUSE`, `SKIP`, `REVIEW_MOVE`, `DEFER` 중 하나로 각 노드를 분류한다. 기존에 수동 작성된 문서를 자동으로 덮어쓰지 않는다.
- `proposed_tree`, `existing_tree`, `diff`, `reuse_matches`, `permissions`, `source_of_truth`, `owner`, `estimated_pages`, `rollback`, `unknowns`를 간결하게 만든다.
- **제목으로만 동일성을 판정하지 않는다.** 관리 매핑 `grafana_dashboard_uid + panel_key → confluence_page_id`를 우선한다. `panel_key`는 버전별 Grafana panel ID/Library panel UID와 의미 ID를 연결한 안정 키로 설계한다. 동일 제목 충돌 시 사용자에게 확인받는다.
- 루트 아래만 수정하는 것이 기본이다. 다른 루트 이동·권한 변경·대량 삭제는 별도 승인한다.

## 5. 사용자 승인 카드 — 최초 또는 구조 변경 때 한 번
Claude는 다음을 제시한다: `현재 루트/추천 루트`, `Grafana 폴더 및 대시보드`, `생성 N/수정 M/재사용 K/보류 Q`, `제안 트리`, `중복 회피 방식`, `권한`, `원본`, `실패 시 복구`, `검증 계획`. 그리고 묻는다.
> “기존 운영문서를 우선 재사용하면서 이 대표 페이지 아래에 하위 트리를 자동 구성하겠습니다. 신규 N개, 수정 M개이며 삭제/권한 확대는 하지 않습니다. 이 범위로 진행할까요?”
승인에는 루트 page ID, 생성·수정 목록 또는 제한 범위, 승인자, 시각, 증거를 남긴다. **승인된 트리 내 반복적인 저위험 생성은 승인 범위에 명시된 경우에만 일괄 실행**할 수 있다. 새 대시보드 영역 추가, 보안 범위 확대, 대량 구조 변경은 다시 승인받는다.

## 6. 실제 생성/수정/검증 절차
1. 루트·대상 페이지·상위 관계·최신 버전·쓰기 권한을 재조회한다. 상위 페이지가 삭제/이동되었으면 중단한다.
2. 부모 페이지가 먼저 존재하는지 확인하고 **부모 → 자식 순서**로 생성한다. 동일 `logical_key`와 `page_id`가 이미 있으면 재사용/업데이트 판단한다. 중복 생성하지 않는다.
3. Confluence Cloud API v2라면 `spaceId`, `parentId`, `title`, `body`를 실제 환경에서 확인된 방식으로 사용한다. Data Center는 해당 버전 API의 `ancestors`, `version` 규칙을 확인한다. API 응답 성공만으로 사용자 접근 성공이라 주장하지 않는다.
4. 업데이트는 현재 버전을 재조회하고 기존 사람이 작성한 내용을 보존하며 diff/충돌 검사를 한다. `409`, `403`, `404`, 제한·속도 제한은 원인별로 처리한다. 무한 재시도·무조건 덮어쓰기는 금지한다.
5. 게시 후 부모/자식 관계, 중복, 본문, Grafana 패널/대시보드 링크, Confluence 링크, 접근 권한을 가능한 별도 읽기 권한으로 검증한다.
6. 부분 성공 시 `PARTIAL`, 권한 부족 시 `BLOCKED`, 미검증은 `NOT_TESTED`. 생성된 페이지 ID는 즉시 기록해 재시작 시 이어서 처리한다. **이미 만든 페이지를 임의로 삭제해 롤백하지 않는다.** 사용자 검토가 필요한 복구안과 수정 기록을 제시한다.

## 7. 주기적 유지관리와 작업 종료 연계
- **이벤트 기반(기본):** 대시보드/패널 생성·삭제·이름/UID 변경, KPI 정의 변경, Runbook 변경, 링크 변경이 있으면 관련 노드만 영향 분석. 문서 변경 필요 시 승인된 범위에 따라 갱신하고, 승인 범위 밖이면 diff를 제시한다.
- **정기 점검(선택):** 회사 정책과 실제 실행 수단이 있으면 주 1회 *변경 탐지*를 제안할 수 있다. 무조건 매주 전체 페이지 재게시하지 않는다. 주기는 사용자가 승인한다. 자동 스케줄러/연결이 없으면 `NOT_SCHEDULED`로 기록하고 Claude가 자동 실행한다고 주장하지 않는다.
- **Drift 검사:** Grafana dashboard/panel 목록 ↔ 매핑 레지스트리 ↔ Confluence 실제 트리를 비교해 `MISSING_PAGE`, `STALE_LINK`, `ORPHAN_PAGE`, `DUPLICATE`, `OUTDATED_METRIC`, `PERMISSION_MISMATCH`, `UNKNOWN` 분류. 기존 문서가 삭제 대상처럼 보이더라도 자동 삭제하지 않는다.
- **폐기:** Grafana 패널 삭제 시 문서 즉시 삭제 금지. 상위 페이지의 ‘사용 종료’ 표시 또는 별도 보관안 제안, 기존 링크 영향 확인 후 승인받는다.
- **완료 보고:** `실제 생성/갱신/재사용/보류 건수`, 페이지 링크와 ID, 검증 결과, 다음 점검, 문서 미일치 항목만 간결히 보고한다.

## 8. 저장할 최소 매핑 레지스트리
`logical_key`, `grafana_folder_uid`, `dashboard_uid`, `panel_key`, `confluence_space_id`, `root_page_id`, `parent_page_id`, `page_id`, `page_version`, `doc_kind`, `source_of_truth`, `last_verified_at`, `state`, `owner`. 사내 Git 또는 승인된 Confluence 인덱스 등 **회사 관리 위치**에 저장하고 개인정보/토큰은 넣지 않는다. 레지스트리 자체가 접근 불가하면 기존 페이지 검색으로 복구하되 `AMBIGUOUS`는 자동 생성 금지.

## 9. 반례 및 차단 기준
- 사용자가 루트 하나를 제공했는데 모든 하위 페이지를 수동 생성하라고 요구 → 설계 실패.
- Grafana 패널을 폴더로 취급하거나 Grafana 폴더와 Confluence 페이지 ID를 혼동 → 실패.
- 동명 페이지 중복 생성, 매번 신규 페이지 생성, 기존 수동 작성 문서 덮어쓰기 → 실패.
- 승인 없이 루트 이동·대량 게시·공개 범위 확대 → 실패.
- 문서만 게시하고 링크/부모관계/권한 검증 누락 → `NOT_TESTED`, 성공 불가.
- 자동 스케줄링 기능이 없는데 주기 실행한다고 약속 → 실패.

## 공식 근거 (제품별 실제 버전 확인 필수)
- Grafana 대시보드/폴더: https://grafana.com/docs/grafana/latest/visualizations/dashboards/manage-dashboards/
- Grafana 폴더 권한: https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/folder-access-control/
- Confluence Cloud REST v2 Page API: https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-page/
- Confluence Cloud 페이지 이동: https://developer.atlassian.com/cloud/confluence/rest/v1/api-group-content---children-and-descendants/
- Confluence Data Center API: https://developer.atlassian.com/server/confluence/rest/v900/api-group-content-resource/

> 실행·동기화·재시도·복구의 안전 조건은 `12_AUTOMATION_EXECUTION_AND_RECOVERY.md`를 우선 적용한다.

### 실제 계층 생성 순서
최초 트리 승인 후에도 상위 문서가 아직 없으면 하위 문서를 바로 게시하지 않는다. `상위 생성 → 실제 응답/재조회로 page ID 검증 → 하위 생성 계획 재계산 → 하위 생성 → 재조회 검증` 순서로 진행한다. 실패·응답 불명·권한 상실 시 하위 게시 중단. 동일 루트 아래 다른 대시보드의 자식 페이지를 재사용하지 않는다.

## 하위 구조와 비파괴 정리
사용자가 생성·지정한 작업용 루트 아래에서만 하위 페이지/폴더를 설계·생성·갱신한다. 루트 자체는 수정하지 않는다. 오래된 페이지 정리는 `DELETE`가 아니라 `MARK_DELETE_CANDIDATE` 계획을 사용하고, `[삭제 대상] ` 표시가 승인된 관리 범위에 포함된 경우에만 실행한다. 제목·ID·부모 경로·본문 불변을 재조회하고, 삭제는 사용자에게 남긴다.
