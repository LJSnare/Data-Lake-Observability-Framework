#!/usr/bin/env python3
"""Adversarial offline checks. No company API or real Claude execution."""
import sys,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from reconciler import plan
G={'complete':True,'dashboards':[{'uid':'d1','title':'대시보드','panels':[{'needs_runbook':True,'metric_key':'m1','title':'지표'}]}]}
C={'complete':True,'root_page_id':'ROOT','pages':[]}
R={'mappings':{}}
def case(g=None,c=None,r=None):return plan(copy.deepcopy(G if g is None else g),copy.deepcopy(C if c is None else c),copy.deepcopy(R if r is None else r))
checks=[]
def test(label,ok):checks.append((label,bool(ok)))
test('normal_plan_only',case()['status']=='PLAN_ONLY')
test('deterministic',case()==case())
test('no_write',case().get('writes_performed')==0)
for label,g,c,r,reason in [
 ('missing_root',None,dict(C,root_page_id=None),None,'ROOT_NOT_VERIFIED'),
 ('incomplete_confluence',None,dict(C,complete=False),None,'INCOMPLETE_DISCOVERY'),
 ('incomplete_grafana',dict(G,complete=False),None,None,'INCOMPLETE_DISCOVERY'),
 ('duplicate_pages',None,dict(C,pages=[{'id':'1'},{'id':'1'}]),None,'DUPLICATE_PAGE_IDS'),
 ('invalid_page',None,dict(C,pages=[{'title':'bad'}]),None,'INVALID_PAGE_SNAPSHOT'),
 ('invalid_registry',None,None,{'mappings':{'x':None}},'INVALID_REGISTRY'),
 ('registry_alias',None,None,{'mappings':{'x':'1','y':'1'}},'REGISTRY_PAGE_ID_COLLISION'),
 ('duplicate_dashboard',dict(G,dashboards=G['dashboards']*2),None,None,'DUPLICATE_DASHBOARD_UID'),
 ('invalid_dashboards',dict(G,dashboards='wrong'),None,None,'INVALID_GRAFANA_SNAPSHOT'),
 ('empty_dashboard_title',dict(G,dashboards=[dict(G['dashboards'][0],title='')]),None,None,'EMPTY_DOCUMENT_TITLE'),
 ('empty_panel_title',dict(G,dashboards=[dict(G['dashboards'][0],panels=[dict(G['dashboards'][0]['panels'][0],title='')])]),None,None,'EMPTY_DOCUMENT_TITLE'),
 ('bad_panel',dict(G,dashboards=[dict(G['dashboards'][0],panels=[None])]),None,None,'INVALID_PANEL_SNAPSHOT'),
 ('missing_metric_key',dict(G,dashboards=[dict(G['dashboards'][0],panels=[dict(G['dashboards'][0]['panels'][0],metric_key=None)])]),None,None,'UNSTABLE_OR_DUPLICATE_METRIC_KEY'),
 ('duplicate_metric_key',dict(G,dashboards=[dict(G['dashboards'][0],panels=G['dashboards'][0]['panels']*2)]),None,None,'UNSTABLE_OR_DUPLICATE_METRIC_KEY'),
]:
 out=case(g,c,r);test(label,out.get('reason')==reason)
for label,parent,managed,expected in [
 ('other_root','OUTSIDE','dashboard:d1','ROOT_ANCESTRY_UNVERIFIED'),
 ('parent_missing','MISSING','dashboard:d1','ROOT_ANCESTRY_UNVERIFIED'),
 ('unowned_page','ROOT',None,'OWNERSHIP_NOT_VERIFIED'),
 ('wrong_owner','ROOT','dashboard:other','OWNERSHIP_NOT_VERIFIED'),
]:
 c=dict(C,pages=[{'id':'P','parent_id':parent,'managed_key':managed,'title':'대시보드'}]);out=case(c=c,r={'mappings':{'dashboard:d1':'P'}})
 test(label,out['actions'][0].get('reason')==expected)
c=dict(C,pages=[{'id':'P','parent_id':'ROOT','managed_key':'dashboard:d1','title':'대시보드'}]);out=case(c=c,r={'mappings':{'dashboard:d1':'P'}})
test('owned_in_root_reuse',out['actions'][0]['action']=='REUSE')
c=dict(C,pages=[{'id':'P','parent_id':'ROOT','managed_key':'dashboard:d1','title':'대시보드','human_edited':True}]);out=case(c=c,r={'mappings':{'dashboard:d1':'P'}})
test('human_edit_review',out['actions'][0].get('reason')=='HUMAN_EDITED')
c=dict(C,pages=[{'id':'P','parent_id':'OUTSIDE','title':'대시보드'}]);out=case(c=c)
test('external_title_not_reused',out['actions'][0]['action']=='CREATE_PROPOSAL')
# A plan proposal does not imply write authorization.
test('proposal_never_write',all(a['action']!='CREATE' for a in case()['actions']))
fail=[name for name,ok in checks if not ok]
print(f'ADVERSARIAL: {len(checks)-len(fail)}/{len(checks)} PASS; NO LIVE INTEGRATION')
if fail: print('FAIL:',', '.join(fail));sys.exit(1)
