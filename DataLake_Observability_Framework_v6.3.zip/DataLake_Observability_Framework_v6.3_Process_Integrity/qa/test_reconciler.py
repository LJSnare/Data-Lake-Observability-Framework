#!/usr/bin/env python3
"""합성 시나리오: 정상/실패 분기 검증. 실제 Confluence API 검증 아님."""
from reconciler import plan
import copy
G={'complete':True,'dashboards':[{'uid':'search1','title':'통합검색','panels':[{'metric_key':'count','title':'검색건수','needs_runbook':True},{'metric_key':'error','title':'검색오류','needs_runbook':True},{'metric_key':'decoration','title':'보조 그래프','needs_runbook':False}]}]}
C={'complete':True,'root_page_id':'ROOT','pages':[]}
R={'mappings':{}}
def run(g=G,c=C,r=R):return plan(copy.deepcopy(g),copy.deepcopy(c),copy.deepcopy(r))
a=run();assert a['status']=='PLAN_ONLY' and len(a['actions'])==3 and a['actions'][0]['action']=='CREATE_PROPOSAL' and all(x['action']=='DEFER_PARENT' for x in a['actions'][1:])
assert run()==a # 재실행 결정성
x=copy.deepcopy(C);x['complete']=False;assert run(c=x)['reason']=='INCOMPLETE_DISCOVERY'
x=copy.deepcopy(C);x['root_page_id']=None;assert run(c=x)['reason']=='ROOT_NOT_VERIFIED'
x=copy.deepcopy(G);x['dashboards'].append(copy.deepcopy(x['dashboards'][0]));assert run(g=x)['reason']=='DUPLICATE_DASHBOARD_UID'
x=copy.deepcopy(G);x['dashboards'][0]['panels'][1]['metric_key']='count';assert run(g=x)['reason']=='UNSTABLE_OR_DUPLICATE_METRIC_KEY'
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'ROOT','title':'통합검색'}];assert run(c=x)['actions'][0]['reason']=='TITLE_COLLISION'
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'ROOT','title':'통합검색','managed_key':'dashboard:search1'}];assert run(c=x)['actions'][0]['reason']=='FOUND_UNREGISTERED_MATCH'
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'ROOT','title':'통합검색','managed_key':'dashboard:search1'},{'id':'2','parent_id':'ROOT','title':'다른제목','managed_key':'dashboard:search1'}];assert run(c=x)['actions'][0]['reason']=='DUPLICATE_MANAGED_KEYS'
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'ROOT','title':'통합검색','managed_key':'dashboard:search1','human_edited':True}];assert run(c=x,r={'mappings':{'dashboard:search1':'1'}})['actions'][0]['reason']=='HUMAN_EDITED'
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'ROOT','title':'통합검색'}];assert run(c=x,r={'mappings':{'dashboard:search1':'999'}})['actions'][0]['reason']=='MAPPED_PAGE_UNAVAILABLE'
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'ROOT','title':'통합검색','managed_key':'dashboard:search1'}];assert run(c=x,r={'mappings':{'dashboard:search1':'1'}})['actions'][0]['action']=='REUSE'
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'ROOT','title':'이전 이름','managed_key':'dashboard:search1'}];assert run(c=x,r={'mappings':{'dashboard:search1':'1'}})['actions'][0]['action']=='UPDATE_PROPOSAL'
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'ROOT','title':'통합검색','managed_key':'dashboard:other'}];assert run(c=x,r={'mappings':{'dashboard:search1':'1'}})['actions'][0]['reason']=='OWNERSHIP_NOT_VERIFIED'
# 동일한 managed_key라도 지정 루트 밖이면 재사용/수정 금지.
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'OTHER_ROOT','title':'통합검색','managed_key':'dashboard:search1'}]
assert run(c=x,r={'mappings':{'dashboard:search1':'1'}})['actions'][0]['reason']=='ROOT_ANCESTRY_UNVERIFIED'
# 부모 관계가 누락되어도 승인된 루트 아래라고 추정 금지.
x=copy.deepcopy(C);x['pages']=[{'id':'1','title':'통합검색','managed_key':'dashboard:search1'}]
assert run(c=x,r={'mappings':{'dashboard:search1':'1'}})['actions'][0]['reason']=='ROOT_ANCESTRY_UNVERIFIED'
# 정상적인 다단계 조상 관계는 인정.
x=copy.deepcopy(C);x['pages']=[{'id':'parent','parent_id':'ROOT','title':'분류'}, {'id':'1','parent_id':'parent','title':'통합검색','managed_key':'dashboard:search1'}]
assert run(c=x,r={'mappings':{'dashboard:search1':'1'}})['actions'][0]['action']=='REUSE'
# 순환 참조는 검증 불가로 차단.
x=copy.deepcopy(C);x['pages']=[{'id':'1','parent_id':'2','title':'통합검색','managed_key':'dashboard:search1'}, {'id':'2','parent_id':'1','title':'순환'}]
assert run(c=x,r={'mappings':{'dashboard:search1':'1'}})['actions'][0]['reason']=='ROOT_ANCESTRY_UNVERIFIED'
assert all('writes_performed' not in run(c=x) or run(c=x)['writes_performed']==0 for x in [C])
print('OFFLINE RECONCILER PASS: 18 synthetic assertions; 0 writes; INTERNAL INTEGRATION NOT_TESTED')
