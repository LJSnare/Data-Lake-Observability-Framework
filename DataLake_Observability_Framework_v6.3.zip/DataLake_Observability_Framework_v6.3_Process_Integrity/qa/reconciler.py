#!/usr/bin/env python3
"""합성 스냅샷용 순수 오프라인 Confluence 계획기. API 연결/쓰기 없음."""
import json,sys

def plan(grafana, confluence, registry):
    if not isinstance(grafana,dict) or not isinstance(confluence,dict) or not isinstance(registry,dict):
        return {'status':'BLOCKED','reason':'INVALID_SNAPSHOT','actions':[]}
    if grafana.get('complete') is not True or confluence.get('complete') is not True:
        return {'status':'BLOCKED','reason':'INCOMPLETE_DISCOVERY','actions':[]}
    root=confluence.get('root_page_id')
    if not isinstance(root,str) or not root.strip(): return {'status':'BLOCKED','reason':'ROOT_NOT_VERIFIED','actions':[]}
    pages=confluence.get('pages')
    if not isinstance(pages,list) or any(not isinstance(p,dict) or not isinstance(p.get('id'),str) or not p['id'].strip() or (p.get('parent_id') is not None and not isinstance(p.get('parent_id'),str)) for p in pages):
        return {'status':'BLOCKED','reason':'INVALID_PAGE_SNAPSHOT','actions':[]}
    if len({p['id'] for p in pages})!=len(pages):
        return {'status':'BLOCKED','reason':'DUPLICATE_PAGE_IDS','actions':[]}
    by_id={p['id']:p for p in pages}
    # root 자체를 반환 목록에 포함하지 않아도 되지만, 각 기존 페이지의
    # parent_id 체인은 지정 루트까지 검증할 수 있어야 한다.
    def under_root(page_id):
        # 루트 자체는 관리 대상 문서가 아니다. 루트 페이지 덮어쓰기 금지.
        if page_id == root:
            return False
        visited=set()
        current=page_id
        while current != root:
            if current in visited or current not in by_id:
                return False
            visited.add(current)
            current=by_id[current].get('parent_id')
            if current is None:
                return False
        return True
    mappings=registry.get('mappings')
    if not isinstance(mappings,dict) or any(not isinstance(k,str) or not isinstance(v,str) or not v for k,v in mappings.items()):
        return {'status':'BLOCKED','reason':'INVALID_REGISTRY','actions':[]}
    if any(not k.strip() or not v.strip() for k,v in mappings.items()):
        return {'status':'BLOCKED','reason':'INVALID_REGISTRY','actions':[]}
    if len(set(mappings.values()))!=len(mappings):
        return {'status':'BLOCKED','reason':'REGISTRY_PAGE_ID_COLLISION','actions':[]}
    if not isinstance(grafana.get('dashboards'),list):
        return {'status':'BLOCKED','reason':'INVALID_GRAFANA_SNAPSHOT','actions':[]}
    actions=[]; seen=set(); planned_titles=set(); dashboard_states={}
    for d in grafana['dashboards']:
        if not isinstance(d,dict): return {'status':'BLOCKED','reason':'INVALID_GRAFANA_SNAPSHOT','actions':[]}
        uid=d.get('uid')
        if not isinstance(uid,str) or not uid.strip() or uid in seen: return {'status':'BLOCKED','reason':'DUPLICATE_DASHBOARD_UID','actions':[]}
        seen.add(uid)
        nodes=[('dashboard:'+uid,'DASHBOARD',root,d.get('title',''),None)]
        metrics=set()
        if not isinstance(d.get('panels'),list): return {'status':'BLOCKED','reason':'INVALID_PANEL_SNAPSHOT','actions':[]}
        for p in d['panels']:
            if not isinstance(p,dict): return {'status':'BLOCKED','reason':'INVALID_PANEL_SNAPSHOT','actions':[]}
            if not isinstance(p.get('needs_runbook'),bool):
                return {'status':'BLOCKED','reason':'INVALID_PANEL_FLAG','actions':[]}
            if not p['needs_runbook']:continue
            key=p.get('metric_key')
            if not isinstance(key,str) or not key.strip() or key in metrics: return {'status':'BLOCKED','reason':'UNSTABLE_OR_DUPLICATE_METRIC_KEY','actions':[]}
            metrics.add(key)
            nodes.append(('panel:'+uid+':'+key,'PANEL','dashboard:'+uid,p.get('title',''),key))
        for logical,kind,parent,title,metric in nodes:
            if not isinstance(title,str) or not title.strip():
                return {'status':'BLOCKED','reason':'EMPTY_DOCUMENT_TITLE','actions':[]}
            # 동일한 부모에 동일한 이름의 새 페이지를 두 개 제안하지 않는다.
            title_identity=(parent,title.strip())
            if title_identity in planned_titles:
                return {'status':'BLOCKED','reason':'DUPLICATE_PROPOSED_SIBLING_TITLE','actions':[]}
            planned_titles.add(title_identity)
            mapped=mappings.get(logical)
            if mapped:
                if mapped not in by_id:
                    actions.append({'key':logical,'action':'REVIEW','reason':'MAPPED_PAGE_UNAVAILABLE','page_id':mapped})
                    continue
                page=by_id[mapped]
                if not under_root(mapped):
                    actions.append({'key':logical,'action':'REVIEW','reason':'ROOT_ANCESTRY_UNVERIFIED','page_id':mapped})
                    continue
                if sum(1 for candidate in pages if candidate.get('managed_key') == logical)>1:
                    actions.append({'key':logical,'action':'REVIEW','reason':'DUPLICATE_MANAGED_KEYS','page_id':mapped})
                    continue
                if page.get('managed_key') != logical:
                    actions.append({'key':logical,'action':'REVIEW','reason':'OWNERSHIP_NOT_VERIFIED','page_id':mapped})
                    continue
                if page.get('human_edited'):
                    actions.append({'key':logical,'action':'REVIEW','reason':'HUMAN_EDITED','page_id':mapped})
                    continue
                if any(other['id']!=mapped and other.get('title')==title and other.get('parent_id')==page.get('parent_id') for other in pages):
                    actions.append({'key':logical,'action':'REVIEW','reason':'TARGET_TITLE_COLLISION','page_id':mapped})
                    continue
                if page.get('title')==title:
                    actions.append({'key':logical,'action':'REUSE','page_id':mapped})
                else:
                    actions.append({'key':logical,'action':'UPDATE_PROPOSAL','page_id':mapped,'title':title})
                continue
            matched=[p for p in pages if p.get('managed_key')==logical]
            if len(matched)==1:
                reason='FOUND_UNREGISTERED_MATCH' if under_root(matched[0]['id']) else 'ROOT_ANCESTRY_UNVERIFIED'
                actions.append({'key':logical,'action':'REVIEW','reason':reason,'page_id':matched[0]['id']})
            elif len(matched)>1:
                actions.append({'key':logical,'action':'REVIEW','reason':'DUPLICATE_MANAGED_KEYS'})
            elif any(p.get('title')==title and under_root(p['id']) for p in pages):
                actions.append({'key':logical,'action':'REVIEW','reason':'TITLE_COLLISION'})
            else:
                actions.append({'key':logical,'action':'CREATE_PROPOSAL','parent_key':parent,'title':title,'kind':kind})
    # A child page must never be treated as independently actionable when its parent
    # dashboard page is unresolved. Even an existing mapped child needs a verified parent.
    action_by_key={a['key']:a for a in actions}
    for action in actions:
        if not action['key'].startswith('panel:'):
            continue
        parent_key='dashboard:'+action['key'].split(':',2)[1]
        parent_action=action_by_key.get(parent_key)
        if not parent_action or parent_action['action'] not in ('REUSE','UPDATE_PROPOSAL'):
            if action['action'] not in ('REVIEW','DEFER_PARENT'):
                action['original_proposal']=action['action']
                action['action']='DEFER_PARENT'
                action['reason']='PARENT_NOT_VERIFIED'
            continue
        # If both pages exist, enforce the *immediate* parent relationship, not
        # merely membership somewhere under the selected Confluence root.
        if action.get('page_id') and parent_action.get('page_id'):
            child=by_id.get(action['page_id'])
            if child and child.get('parent_id')!=parent_action['page_id']:
                action['action']='REVIEW'
                action['reason']='IMMEDIATE_PARENT_MISMATCH'
    return {'status':'PLAN_ONLY','root_page_id':root,'actions':actions,'writes_performed':0}

if __name__=='__main__':
    if len(sys.argv)!=4:sys.exit('usage: python qa/reconciler.py grafana.json confluence.json registry.json')
    with open(sys.argv[1],encoding='utf-8') as f:g=json.load(f)
    with open(sys.argv[2],encoding='utf-8') as f:c=json.load(f)
    with open(sys.argv[3],encoding='utf-8') as f:r=json.load(f)
    print(json.dumps(plan(g,c,r),ensure_ascii=False,indent=2))
