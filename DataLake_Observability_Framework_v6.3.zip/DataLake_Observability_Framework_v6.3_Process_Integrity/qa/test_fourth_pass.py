#!/usr/bin/env python3
"""4차 감사: 계층 의존성, 잘못된 직계 부모, 제목 변경 충돌, 무쓰기."""
import copy,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from reconciler import plan
G={'complete':True,'dashboards':[{'uid':'d1','title':'검색','panels':[{'needs_runbook':True,'metric_key':'m1','title':'검색량'}]}]}
C={'complete':True,'root_page_id':'R','pages':[]}
R={'mappings':{}}
n=0
def check(g,c,r,expected):
 global n
 out=plan(copy.deepcopy(g),copy.deepcopy(c),copy.deepcopy(r))
 assert out['status']=='PLAN_ONLY',out
 assert [a['action'] for a in out['actions']]==expected,out
 assert out['writes_performed']==0
 n+=1
 return out
# New dashboard: child must wait for parent actually created/verified
check(G,C,R,['CREATE_PROPOSAL','DEFER_PARENT'])
# Parent exists and is verified: child can be proposed
c=copy.deepcopy(C);c['pages']=[{'id':'D','parent_id':'R','title':'검색','managed_key':'dashboard:d1'}]
r={'mappings':{'dashboard:d1':'D'}}
check(G,c,r,['REUSE','CREATE_PROPOSAL'])
# Child exists under unrelated dashboard, though still under the same approved root
c2=copy.deepcopy(c);c2['pages'] += [{'id':'OTHER','parent_id':'R','title':'기타'}, {'id':'P','parent_id':'OTHER','title':'검색량','managed_key':'panel:d1:m1'}]
r2={'mappings':{'dashboard:d1':'D','panel:d1:m1':'P'}}
out=check(G,c2,r2,['REUSE','REVIEW'])
assert out['actions'][1]['reason']=='IMMEDIATE_PARENT_MISMATCH'
# Parent unresolved: do not allow already mapped child to be updated/reused
c3=copy.deepcopy(c2);c3['pages'][0]['managed_key']='unowned'
out=check(G,c3,r2,['REVIEW','DEFER_PARENT'])
# Rename to an already existing sibling title must not generate update proposal
c4=copy.deepcopy(c);c4['pages'] += [{'id':'P','parent_id':'D','title':'이전','managed_key':'panel:d1:m1'}, {'id':'X','parent_id':'D','title':'검색량'}]
r4={'mappings':{'dashboard:d1':'D','panel:d1:m1':'P'}}
out=check(G,c4,r4,['REUSE','REVIEW'])
assert out['actions'][1]['reason']=='TARGET_TITLE_COLLISION'
# Multiple independent dashboards remain separate, no writes
for i in range(150):
 g=copy.deepcopy(G);g['dashboards'][0]['uid']='d'+str(i);g['dashboards'][0]['title']='검색'+str(i)
 check(g,C,R,['CREATE_PROPOSAL','DEFER_PARENT'])
print(f'FOURTH PASS PASS: {n} synthetic scenarios; no writes')
