from pathlib import Path
import unittest,re
ROOT=Path(__file__).resolve().parents[1]
class Semantics(unittest.TestCase):
 def test_single_start_version(self):
  s=(ROOT/'00_START_HERE.md').read_text()
  self.assertIn('v6.3 단일 기준본',s)
  self.assertNotRegex(s,r'v5\.(?:3|4|5|6|7)')
 def test_all_normative_docs(self):
  s=(ROOT/'00_START_HERE.md').read_text()
  for i in ('16_','17_','18_','19_'):self.assertIn(i,s)
 def test_delegation_separate(self):
  s=(ROOT/'18_APPROVAL_AND_SESSION_LEDGER.md').read_text()
  for token in ('작업영역 지정','위임 승인','철회','원장','쓰기만 보류'):self.assertIn(token,s)
 def test_partial_success(self):
  s=(ROOT/'19_GRAFANA_CREATION_AND_PARTIAL_RECOVERY.md').read_text()
  for token in ('CREATE_PANEL','CREATE_DASHBOARD','DOC_PENDING','UNKNOWN_COMMIT','무조건 되돌리지 않는다','프롬프트 인젝션'):self.assertIn(token,s)
 def test_delete_non_destructive(self):
  s=(ROOT/'16_WORKSPACE_SCOPE_AND_NONDESTRUCTIVE_POLICY.md').read_text()
  self.assertIn('[삭제 대상]',s)
  self.assertIn('실제 삭제',s)
if __name__=='__main__':unittest.main()
