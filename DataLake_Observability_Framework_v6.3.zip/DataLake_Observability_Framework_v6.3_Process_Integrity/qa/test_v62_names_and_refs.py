#!/usr/bin/env python3
from pathlib import Path
import re,unicodedata,urllib.parse
r=Path(__file__).resolve().parents[1]
root=sorted(r.glob('[0-9][0-9]_*.md'))
assert len(root)==22
for i,p in enumerate(root):
 assert re.fullmatch(rf'{i:02d}_[A-Z0-9_]+\.md',p.name),p.name
 assert unicodedata.normalize('NFC',p.name)==p.name
assert (r/'문서_안내.md').exists()
allfiles={p.name for p in root}
for p in [*root,*r.glob('프레임워크_*.md'),r/'문서_안내.md']:
 s=p.read_text(encoding='utf-8')
 for name in re.findall(r'(?<![A-Za-z0-9_])\d\d_[A-Z0-9_]+\.md',s):
  assert name in allfiles,(p.name,name)
 for target in re.findall(r'\]\(([^)]+)\)',s):
  target=urllib.parse.unquote(target.split('#')[0])
  if not target or '://' in target or target.startswith(('mailto:','#')):continue
  if target.endswith('.md') and not target.startswith('/'):
   assert (p.parent/target).exists(),(p.name,target)
assert 'v6.3 단일 기준본' in (r/'00_START_HERE.md').read_text(encoding='utf-8')
print('V6.2 ENGLISH FILENAMES + KOREAN INDEX + LOCAL REFERENCES PASS')
