#!/usr/bin/env python3
"""Confluence/Grafana 작업 범위 및 비파괴 처리 합성 반례."""
from scope_guards import *
checks=0
for title,expected in [('오래된 문서','[삭제 대상] 오래된 문서'),('[삭제 대상] 오래된 문서','[삭제 대상] 오래된 문서')]:
 assert deletion_marker(title)==expected;assert deletion_marker(deletion_marker(title))==expected;checks+=2
for bad in (None,'','   ',0,[]):
 try:deletion_marker(bad);raise AssertionError('must fail')
 except ValueError:checks+=1
ok=dict(root_id='R',page_id='P',ancestry=['P','R'],managed=True,approved=True,permission=True)
assert confluence_mark_allowed(**ok);checks+=1
for key,val in [('root_id','X'),('page_id','R'),('ancestry',[]),('ancestry',['P','X']),('ancestry',['P','P','R']),('managed',False),('approved',False),('permission',False),('concurrent',True),('title_collision',True),('dependencies_unverified',True)]:
 arg=dict(ok);arg[key]=val;assert not confluence_mark_allowed(**arg),(key,val);checks+=1
okg=dict(folder_uid='F',dashboard_uid='D',approved_folder_uid='F',approved_dashboard_uids={'D'},allowed_panel_ids={'1','2'},requested_panel_ids={'1'})
assert grafana_edit_allowed(**okg);checks+=1
for key,val in [('folder_uid','OTHER'),('dashboard_uid','OTHER'),('approved_folder_uid','OTHER'),('approved_dashboard_uids',set()),('requested_panel_ids',{'3'}),('shared_resource',True),('provisioned',True),('concurrent',True)]:
 arg=dict(okg);arg[key]=val;assert not grafana_edit_allowed(**arg),(key,val);checks+=1
for op in ['DELETE','TRASH','ARCHIVE','MOVE','CHANGE_PERMISSIONS','DELETE_DASHBOARD','EDIT_DATASOURCE','EDIT_LIBRARY_PANEL','EDIT_ALERT_RULE','EDIT_PROVISIONING']:
 assert prohibited_operation(op);checks+=1
print(f'WORKSPACE SCOPE PASS: {checks} synthetic assertions; no live writes')
