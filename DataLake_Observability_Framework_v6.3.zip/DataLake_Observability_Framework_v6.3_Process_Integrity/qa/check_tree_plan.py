#!/usr/bin/env python3
"""오프라인 트리 계획 계약 검사. 사내 API 실행/게시 성공을 증명하지 않는다."""
import json,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[1]
def check(plan):
 errors=[]
 nodes=plan.get('proposed_nodes',[])
 keys=[n.get('logical_key') for n in nodes]
 if not keys or len(keys)!=len(set(keys)):errors.append('duplicate_or_empty_keys')
 seen={'root'}
 for node in nodes:
  if node.get('parent_key') not in seen:errors.append('missing_parent_or_wrong_order:'+str(node.get('logical_key')))
  if node.get('kind')=='PANEL' and node.get('parent_key')=='root':errors.append('panel_without_dashboard')
  if node.get('action')=='CREATE_CHILD' and node.get('page_id') is not None:errors.append('create_existing_page')
  if node.get('action') in ('DELETE','MOVE_ROOT','EXPAND_PERMISSIONS'):errors.append('unsafe_action')
  seen.add(node.get('logical_key'))
 if plan.get('status')=='APPROVED':
  a=plan.get('approval') or {}
  if not all(isinstance(a.get(k),str) and a[k].strip() for k in ('approver','timestamp','scope','evidence_uri')):errors.append('approval_missing')
  if not (plan.get('root') or {}).get('verified'):errors.append('root_not_verified')
 if plan.get('execution')=='SUCCEEDED' and plan.get('status')!='APPROVED':errors.append('success_without_approval')
 return errors
p=json.loads((root/'templates/DOCUMENT_TREE_PLAN.example.json').read_text(encoding='utf-8'))
assert not check(p),check(p)
mutations=[]
def bad(tag,mutate,expected):
 x=json.loads(json.dumps(p));mutate(x);issues=check(x)
 if expected not in issues:raise AssertionError(tag+': '+str(issues))
 mutations.append(tag)
bad('duplicate_key',lambda x:x['proposed_nodes'][1].update(logical_key='dashboard:search'),'duplicate_or_empty_keys')
bad('missing_parent',lambda x:x['proposed_nodes'][1].update(parent_key='not-found'),'missing_parent_or_wrong_order:panel:search:requests')
bad('panel_at_root',lambda x:x['proposed_nodes'][1].update(parent_key='root'),'panel_without_dashboard')
bad('unauthorized_approval',lambda x:x.update(status='APPROVED'),'approval_missing')
bad('false_success',lambda x:x.update(execution='SUCCEEDED'),'success_without_approval')
bad('unsafe_action',lambda x:x['proposed_nodes'][1].update(action='DELETE'),'unsafe_action')
print('TREE PLAN PASS: 1 normal example +',len(mutations),'negative cases; NO integration assertions')
