#!/usr/bin/env python3
"""정적 계약 검사. 실제 Confluence TOC 클릭/렌더링 테스트가 아니다."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
policy=(root/'15_CONFLUENCE_ACCESS_AND_PAGE_DESIGN.md').read_text(encoding='utf-8')
assert '기존에 작동 중인' in policy and 'TOC_UNVERIFIED' in policy
assert 'ROOT' not in policy[:40]
for name in ['CONFLUENCE_PANEL_RUNBOOK_KO.example.md','CONFLUENCE_DASHBOARD_OVERVIEW_KO.example.md']:
 s=(root/'templates'/name).read_text(encoding='utf-8')
 assert 'TOC_MACRO_PLACEHOLDER' in s
 assert s.count('\n## ')>=5
 assert 'NOT_TESTED' in s
 assert '실제' in s
 assert '문자 그대로 게시' in s or '게시 시 제거' in s
print('PAGE DESIGN CONTRACT PASS: 2 sample pages, policy checked; live TOC NOT_TESTED')
