#!/usr/bin/env python3
"""3차 실패 유도 검사: 불완전 조회, 잘못된 소유권, 계획 내부 충돌."""
import copy,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from reconciler import plan
G={'complete':True,'dashboards':[{'uid':'d1','title':'통합검색','panels':[{'needs_runbook':True,'metric_key':'m1','title':'검색건수'}]}]}
C={'complete':True,'root_page_id':'ROOT','pages':[]}
R={'mappings':{}}
n=0
def blocked(g=G,c=C,r=R,reason=None):
 global n
 o=plan(copy.deepcopy(g),copy.deepcopy(c),copy.deepcopy(r))
 assert o['status']=='BLOCKED' and o['actions']==[] and o['reason']==reason, o
 n+=1
for value in ('true','yes',1,[],{},None,False):
 g=copy.deepcopy(G);g['complete']=value;blocked(g=g,reason='INCOMPLETE_DISCOVERY')
 c=copy.deepcopy(C);c['complete']=value;blocked(c=c,reason='INCOMPLETE_DISCOVERY')
c=copy.deepcopy(C);del c['pages'];blocked(c=c,reason='INVALID_PAGE_SNAPSHOT')
blocked(r={},reason='INVALID_REGISTRY')
c=copy.deepcopy(C);c['pages']=[{'id':'P','parent_id':[],'managed_key':'dashboard:d1'}]
blocked(c=c,reason='INVALID_PAGE_SNAPSHOT')
g=copy.deepcopy(G);g['dashboards'].append({'uid':'d2','title':'통합검색','panels':[]})
blocked(g=g,reason='DUPLICATE_PROPOSED_SIBLING_TITLE')
g=copy.deepcopy(G);g['dashboards'][0]['panels'].append({'needs_runbook':True,'metric_key':'m2','title':'검색건수'})
blocked(g=g,reason='DUPLICATE_PROPOSED_SIBLING_TITLE')
c=copy.deepcopy(C)
c['pages']=[{'id':'P','parent_id':'ROOT','title':'통합검색','managed_key':'dashboard:d1'},
            {'id':'Q','parent_id':'ROOT','title':'다른 제목','managed_key':'dashboard:d1'}]
o=plan(G,c,{'mappings':{'dashboard:d1':'P'}})
assert o['status']=='PLAN_ONLY' and o['actions'][0]['action']=='REVIEW' and o['actions'][0]['reason']=='DUPLICATE_MANAGED_KEYS';n+=1
for i in range(100):
 g=copy.deepcopy(G);g['dashboards'][0]['title']='대시보드'+str(i)
 o=plan(g,C,R)
 assert o['status']=='PLAN_ONLY' and o['writes_performed']==0
 assert all(a['action'] not in ('CREATE','UPDATE','DELETE') for a in o['actions'])
 n+=1
print(f'THIRD PASS PASS: {n} assertions; all synthetic, no writes')
