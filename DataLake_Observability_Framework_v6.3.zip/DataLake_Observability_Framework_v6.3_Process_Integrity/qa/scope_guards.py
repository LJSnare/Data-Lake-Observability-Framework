"""Fail-closed, offline policy predicates. No API calls and no authorization source."""
PREFIX='[삭제 대상] '
FORBIDDEN={'DELETE','TRASH','ARCHIVE','MOVE','CHANGE_PERMISSIONS','DELETE_DASHBOARD','EDIT_DATASOURCE','EDIT_LIBRARY_PANEL','EDIT_ALERT_RULE','EDIT_PROVISIONING','DELETE_PANEL','DELETE_FOLDER','DELETE_PAGE','RESTORE_WHOLE_DASHBOARD'}

def deletion_marker(title):
    if not isinstance(title,str) or not title.strip(): raise ValueError('INVALID_TITLE')
    if title.startswith('[삭제 대상]'):
        # Preserve idempotency, but do not silently normalize existing human text.
        return title
    return PREFIX+title

def confluence_mark_allowed(*,root_id,page_id,ancestry,managed,approved,permission,concurrent=False,title_collision=False,dependencies_unverified=False):
    if not all(isinstance(x,str) and x.strip() for x in (root_id,page_id)) or page_id==root_id:return False
    if not isinstance(ancestry,(list,tuple)) or len(ancestry)<2:return False
    if not all(isinstance(x,str) and x.strip() for x in ancestry):return False
    # Ordered ancestry is [target, direct parent, ..., root], not an unordered list.
    if ancestry[0]!=page_id or ancestry[-1]!=root_id or len(ancestry)!=len(set(ancestry)):return False
    if not all(v is True for v in (managed,approved,permission)):return False
    if not all(v is False for v in (concurrent,title_collision,dependencies_unverified)):return False
    return True

def grafana_edit_allowed(*,folder_uid,dashboard_uid,approved_folder_uid,approved_dashboard_uids,allowed_panel_ids,requested_panel_ids,shared_resource=False,provisioned=False,concurrent=False):
    if not all(isinstance(x,str) and x.strip() for x in (folder_uid,dashboard_uid,approved_folder_uid)):return False
    if folder_uid!=approved_folder_uid:return False
    if not isinstance(approved_dashboard_uids,(set,list,tuple)) or dashboard_uid not in approved_dashboard_uids:return False
    if not isinstance(allowed_panel_ids,(set,list,tuple)) or not isinstance(requested_panel_ids,(set,list,tuple)):return False
    if not requested_panel_ids or not allowed_panel_ids:return False
    if any(not isinstance(x,(str,int)) or isinstance(x,bool) or str(x).strip()=='' for x in list(allowed_panel_ids)+list(requested_panel_ids)):return False
    if not set(requested_panel_ids).issubset(set(allowed_panel_ids)):return False
    return all(v is False for v in (shared_resource,provisioned,concurrent))

def prohibited_operation(op):
    return not isinstance(op,str) or not op.strip() or op.strip().upper() in FORBIDDEN

def verify_target_only_diff(before,after,allowed_paths):
    """Verify changed JSON paths are strictly allowed. Explicitly reject deletions.
    Callers must additionally validate scope, baseline version and external effects.
    """
    if not isinstance(before,dict) or not isinstance(after,dict):return False
    if not isinstance(allowed_paths,(set,list,tuple)) or not allowed_paths:return False
    if any(not isinstance(p,tuple) or not p or any(not isinstance(s,(str,int)) or isinstance(s,bool) for s in p) for p in allowed_paths):return False
    changes=[]
    def walk(a,b,path):
        if type(a)!=type(b):changes.append(path);return
        if isinstance(a,dict):
            if set(a)!=set(b):
                # key additions/removals must be explicitly allowed, removals never permitted
                for k in set(a)-set(b):changes.append(path+(k,));changes.append(('__REMOVED__',))
                for k in set(b)-set(a):changes.append(path+(k,))
            for k in set(a)&set(b):walk(a[k],b[k],path+(k,))
        elif isinstance(a,list):
            if len(a)!=len(b):changes.append(('__LIST_STRUCTURE_CHANGE__',))
            else:
                for i,(x,y) in enumerate(zip(a,b)):walk(x,y,path+(i,))
        elif a!=b:changes.append(path)
    walk(before,after,())
    return bool(changes) and all(c in allowed_paths for c in changes)
