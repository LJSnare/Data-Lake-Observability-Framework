#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]
start=(r/'00_START_HERE.md').read_text(encoding='utf8')
g=(r/'21_END_TO_END_PROCESS_GATES.md').read_text(encoding='utf8')
checks={
 'required_16_17_18_21':all(x in start for x in ['00, 16, 17, 18, 21','16, 17, 18, 21']),
 'read_first': '00·16·17·18·21·19' in start,
 'task_types':all(x in g for x in ['GENERAL_DOC','KPI_PANEL','PANEL_RUNBOOK','DOC_ONLY_UPDATE','DRIFT_REVIEW']),
 'kpi_gate': 'KPI_VERIFIED' in g and '실제 KPI 패널 게시를 차단' in start,
 'status_separation':all(x in g for x in ['전체 작업 상태','개별 단계 상태','증거 게이트 플래그']),
 'partial':all(x in g for x in ['PARTIAL','Grafana 성공·Confluence 실패','Confluence만']),
 'revocation':all(x in g for x in ['승인 철회','계약 변경','재시도 직전']),
 'publication':all(x in g for x in ['CONTENT','DESIGN','NAVIGATION','ACCESS','MAINTENANCE']),
 'unknown_outcome':'UNKNOWN_OUTCOME' in g,
 'no_delete':'실제 삭제/보관/이동 금지' in g,
 'no_fake_integration':'NOT_TESTED' in g,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
assert all(checks.values())
