#!/usr/bin/env python3
"""독립 2차 부정 검증: 계획기 예외, 루트 보호, 오염 입력, 전역 차단."""
import copy, json, sys, random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from reconciler import plan
root=Path(__file__).parents[1]
g=json.loads((root/'fixtures/grafana.synthetic.json').read_text(encoding='utf-8'))
c=json.loads((root/'fixtures/confluence.synthetic.json').read_text(encoding='utf-8'))
r=json.loads((root/'fixtures/registry.synthetic.json').read_text(encoding='utf-8'))
assert plan(g,c,r)['status']=='PLAN_ONLY'
checks=0
def check(g1,c1,r1,reason):
 global checks
 result=plan(g1,c1,r1)
 assert result['status']=='BLOCKED' and result['reason']==reason, (reason,result)
 assert not result['actions']
 checks+=1
for invalid in [None,1,[],True,'bad']:
 a=copy.deepcopy(g);a['dashboards']=[invalid];check(a,c,r,'INVALID_GRAFANA_SNAPSHOT')
for invalid in [None,1,'bad',True]:
 a=copy.deepcopy(g);a['dashboards'][0]['panels']=[invalid];check(a,c,r,'INVALID_PANEL_SNAPSHOT')
for invalid in [None,1,{},'yes']:
 a=copy.deepcopy(g);a['dashboards'][0]['panels'][0]['needs_runbook']=invalid;check(a,c,r,'INVALID_PANEL_FLAG')
for invalid in [None,1,{},'bad']:
 a=copy.deepcopy(g);a['dashboards'][0]['panels']=invalid;check(a,c,r,'INVALID_PANEL_SNAPSHOT')
for invalid in [None,1,{},'bad']:
 a=copy.deepcopy(g);a['dashboards']=invalid;check(a,c,r,'INVALID_GRAFANA_SNAPSHOT')
for invalid in ['', '  ']:
 a=copy.deepcopy(r);a['mappings']={'dashboard:EXAMPLE_SEARCH':invalid};check(g,c,a,'INVALID_REGISTRY')
# root 페이지를 매핑에 넣더라도 자동 수정/재사용하면 안 됨
for page_root_present in (True,False):
 a=copy.deepcopy(c)
 rootid=a['root_page_id']
 if page_root_present:
  a['pages'].append({'id':rootid,'parent_id':None,'title':'대표 페이지','managed_key':'dashboard:EXAMPLE_SEARCH'})
 b={'mappings':{'dashboard:EXAMPLE_SEARCH':rootid}}
 result=plan(g,a,b)
 assert result['status']=='PLAN_ONLY'
 target=[x for x in result['actions'] if x['key']=='dashboard:EXAMPLE_SEARCH'][0]
 assert target['action']=='REVIEW', target
 checks+=1
# 임의 JSON 타입 조합에도 계획기가 예외로 죽지 않는지 검증
rng=random.Random(20261015)
pool=[None,0,1,True,False,'',[],{},'bad']
for i in range(300):
 a,b,d=copy.deepcopy(g),copy.deepcopy(c),copy.deepcopy(r)
 field=rng.choice(['dashboard','panel','page','mapping'])
 val=copy.deepcopy(rng.choice(pool))
 if field=='dashboard':a['dashboards']=[val]
 elif field=='panel':a['dashboards'][0]['panels']=[val]
 elif field=='page':b['pages']=[val]
 else:d['mappings']=val
 try: out=plan(a,b,d)
 except Exception as e: raise AssertionError((field,val,e))
 assert out['status'] in ('BLOCKED','PLAN_ONLY')
 assert out.get('writes_performed',0)==0
 checks+=1
print(f'SECOND PASS PASS: {checks} assertions, 300 malformed-input probes, zero writes; synthetic only')
