#!/usr/bin/env python3
"""Synthetic policy gate checks; no Confluence API calls."""
import json
from pathlib import Path
cases=json.loads((Path(__file__).parent/'ROOT_GATE_CASES.json').read_text(encoding='utf-8'))
def decision(x):
    if not x.get('root_confirmed') or not x.get('scope_approved'): return 'BLOCK'
    if not x.get('within_scope') or not x.get('root_valid',True): return 'BLOCK'
    if not x.get('write_permission',True) or x.get('outside_root',False): return 'BLOCK'
    if x.get('operation','UPDATE') in ('DELETE','MOVE','PERMISSION_CHANGE'): return 'BLOCK'
    return 'ALLOW'
for x in cases:
    actual=decision(x)
    assert actual==x['expected'], (x['case'],actual,x['expected'])
print(f"ROOT_GATE PASS: {len(cases)} synthetic cases; NOT live permissions verification")
