#!/usr/bin/env python3
from scope_guards import *
import copy
checks=0
ok=dict(root_id='R',page_id='P',ancestry=['P','A','R'],managed=True,approved=True,permission=True)
assert confluence_mark_allowed(**ok);checks+=1
for bad in [['A','P','R'],['P','R','A'],['P','A','R','R'],['P','A','X'],['P','R','A','R']]:
 a=dict(ok,ancestry=bad);assert not confluence_mark_allowed(**a);checks+=1
for field in ['managed','approved','permission']:
 for val in [1,'true',None,[],{}]:
  a=dict(ok);a[field]=val;assert not confluence_mark_allowed(**a);checks+=1
for field in ['concurrent','title_collision','dependencies_unverified']:
 for val in [1,'false',None,[],{}]:
  a=dict(ok);a[field]=val;assert not confluence_mark_allowed(**a);checks+=1
g=dict(folder_uid='F',dashboard_uid='D',approved_folder_uid='F',approved_dashboard_uids={'D'},allowed_panel_ids={1,2},requested_panel_ids={1})
assert grafana_edit_allowed(**g);checks+=1
for field,val in [('requested_panel_ids',set()),('allowed_panel_ids',set()),('approved_dashboard_uids','D'),('requested_panel_ids',{True}),('allowed_panel_ids',{None}),('requested_panel_ids',{3})]:
 a=dict(g);a[field]=val;assert not grafana_edit_allowed(**a),(field,val);checks+=1
for field in ['shared_resource','provisioned','concurrent']:
 for val in [1,'false',None]:
  a=dict(g);a[field]=val;assert not grafana_edit_allowed(**a);checks+=1
for op in [' delete ','DELETE_PANEL','RESTORE_WHOLE_DASHBOARD','DELETE_FOLDER','DELETE_PAGE','']:
 assert prohibited_operation(op);checks+=1
before={'uid':'D','version':3,'panels':[{'id':1,'title':'Old'},{'id':2,'title':'Untouched'}]}
after=copy.deepcopy(before);after['panels'][0]['title']='New'
assert verify_target_only_diff(before,after,{('panels',0,'title')});checks+=1
for change in ['non_target','uid','version','remove','add','reorder']:
 a=copy.deepcopy(after)
 if change=='non_target':a['panels'][1]['title']='Hacked'
 if change=='uid':a['uid']='Other'
 if change=='version':a['version']=4
 if change=='remove':del a['panels'][1]
 if change=='add':a['newfield']=1
 if change=='reorder':a['panels'].reverse()
 assert not verify_target_only_diff(before,a,{('panels',0,'title')}),change
 checks+=1
# A no-op cannot be presented as a confirmed change.
assert not verify_target_only_diff(before,before,{('panels',0,'title')});checks+=1
print(f'FINAL SAFETY PASS: {checks} adversarial assertions; offline only')
