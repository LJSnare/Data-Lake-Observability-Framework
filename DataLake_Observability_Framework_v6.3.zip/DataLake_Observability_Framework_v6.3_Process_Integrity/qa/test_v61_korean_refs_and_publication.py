#!/usr/bin/env python3
from pathlib import Path
import re,unicodedata
r=Path(__file__).resolve().parents[1]
rootdocs=sorted(p for p in r.glob('[0-9][0-9]_*.md'))
assert len(rootdocs)==22
for i,p in enumerate(rootdocs):
 assert re.fullmatch(r'\d\d_[A-Z0-9_]+\.md',p.name),p.name
 assert p.name.startswith(f'{i:02d}_'),p.name
 assert p.stat().st_size>100
start=rootdocs[0].read_text();assert 'v6.3 단일 기준본' in start
for p in r.glob('프레임워크_*.md'):
 s=p.read_text();assert 'v6.1' in s or 'v6.3' in s
policy=rootdocs[15].read_text();new=rootdocs[20].read_text()
for word in ['TOC_UNVERIFIED','H2','H3','PARTIAL','NOT_TESTED','[삭제 대상]']:
 assert word in policy+new,word
print('LEGACY PUBLICATION CONTRACT PASS (ENGLISH NAMES); LIVE RENDER NOT_TESTED')
