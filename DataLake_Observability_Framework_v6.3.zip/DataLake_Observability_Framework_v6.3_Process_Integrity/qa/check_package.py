#!/usr/bin/env python3
"""패키지 L0 정적 검사만 수행. 사내 연동 PASS를 주장하지 않는다."""
import json, pathlib, csv, io, sys, hashlib
root=pathlib.Path(__file__).resolve().parents[1]
errors=[]
required=[f'{i:02d}_' for i in range(22)]
md=list(root.glob('*.md'))
for prefix in required:
 if sum(f.name.startswith(prefix) for f in md)!=1: errors.append('missing_or_duplicate_document:'+prefix)
for f in (root/'templates').glob('*.json'):
 try: json.loads(f.read_text(encoding='utf-8'))
 except Exception as e: errors.append('invalid_json:'+f.name+':'+str(e))
card=json.loads((root/'templates/DECISION_CARD.example.json').read_text(encoding='utf-8'))
if card['status']!='PENDING' or card['approval']['approver'] is not None: errors.append('unsafe_example_approval')
contract=json.loads((root/'templates/METRIC_CONTRACT.example.json').read_text(encoding='utf-8'))
if contract['status']!='PROPOSED' or contract['data_quality']!='NOT_TESTED': errors.append('unsafe_example_metric')
with (root/'qa/ACCEPTANCE_MATRIX.tsv').open(encoding='utf-8',newline='') as f: rows=list(csv.DictReader(f,delimiter='\t'))
if len(rows)!=20 or len({r['id'] for r in rows})!=20: errors.append('acceptance_case_count_or_duplicates')
if any(r['pre_handoff_status']!='NOT_TESTED' for r in rows): errors.append('false_test_pass')
for name in ['00_START_HERE.md','01_AGENT_OPERATING_CONTRACT.md','02_METRIC_AND_DATA_TRUTH.md','03_GRAFANA_CONFLUENCE_DECISIONS.md','04_EVIDENCE_TESTS_AND_RELEASE.md','05_EVOLUTION_AND_SCORECARD.md','06_REQUIREMENTS_TRACEABILITY.md','07_OFFICIAL_SOURCES_AND_UNKNOWNS.md','08_WORKED_PILOT_AND_DECISION_EXAMPLES.md','09_REACT_FUTURE_INSTRUMENTATION.md','10_CONFLUENCE_LIFECYCLE_AND_PUBLICATION.md','11_AUTONOMOUS_CONFLUENCE_TREE_ORCHESTRATION.md','12_AUTOMATION_EXECUTION_AND_RECOVERY.md','13_CONFLUENCE_ROOT_DELEGATION.md','14_FAILURE_MODES_AND_DECISION_PROCEDURE.md','15_CONFLUENCE_ACCESS_AND_PAGE_DESIGN.md','16_WORKSPACE_SCOPE_AND_NONDESTRUCTIVE_POLICY.md','17_FINAL_OPERATIONAL_GATES.md','18_APPROVAL_AND_SESSION_LEDGER.md','19_GRAFANA_CREATION_AND_PARTIAL_RECOVERY.md','20_CONFLUENCE_PUBLICATION_QUALITY.md','21_END_TO_END_PROCESS_GATES.md']:
 if not (root/name).exists(): errors.append('missing:'+name)
# MANIFEST에 명시된 파일의 SHA256과 실제 내용을 대조한다.
manifest=json.loads((root/'release/MANIFEST.json').read_text(encoding='utf-8'))
for rel, expected in manifest.get('files',{}).items():
 target=root/rel
 if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=expected:
  errors.append('manifest_hash_mismatch:'+rel)
# Manifest 파일 목록과 실제 배포 파일 집합이 동일한지 확인한다.
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name not in ('MANIFEST.json','SHA256SUMS.txt') and '__pycache__' not in p.parts}
if set(manifest.get('files',{}))!=actual: errors.append('manifest_inventory_mismatch')
# 승인 예시를 단순 문자열로 검사하지 않고 승인 객체의 필수 필드까지 확인한다.
def approval_valid(approval):
 return isinstance(approval,dict) and all(
  isinstance(approval.get(k),str) and approval[k].strip() and approval[k] not in ('UNKNOWN','NOT_AVAILABLE_YET')
  for k in ('approver','timestamp','evidence_uri','scope'))
if card.get('status')=='APPROVED' and not approval_valid(card.get('approval')):
 errors.append('approved_without_valid_evidence')
if card.get('status')=='DEPLOYED':
 if not approval_valid(card.get('approval')) or not approval_valid(card.get('deployment_approval')):
  errors.append('deployed_without_two_approvals')
if errors:
 print('L0 FAIL:',*errors,sep='\n- ');sys.exit(1)
print('L0 PASS: docs=22, scenarios=20 NOT_TESTED, hashes verified, approval guard; NOT integration')
