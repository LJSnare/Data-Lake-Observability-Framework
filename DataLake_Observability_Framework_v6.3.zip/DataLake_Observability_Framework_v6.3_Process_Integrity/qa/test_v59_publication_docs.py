from pathlib import Path
root=Path(__file__).resolve().parents[1]
files=['프레임워크_소개_및_운영설명서.md','프레임워크_전체_진행순서_및_운영절차.md']
for f in files:
 s=(root/f).read_text(encoding='utf-8')
 for word in ['## 목차','Confluence','Grafana','OpenSearch','[삭제 대상]','승인','검증']:
  assert word in s,(f,word)
 assert '목차(Table of Contents) 매크로' in s or '목차(Table of Contents)' in s or 'TOC 매크로' in s
assert 'v6.3 단일 기준본' in (root/'00_START_HERE.md').read_text(encoding='utf-8')
print('publication docs PASS (v6.3) (static only)')
