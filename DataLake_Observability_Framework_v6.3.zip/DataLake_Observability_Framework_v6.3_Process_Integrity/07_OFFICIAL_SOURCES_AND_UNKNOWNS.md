# 07. 기술 근거·적용 조건·미확인 사항

공식 문서의 **기능 존재**는 확인 가능하지만 **사내 설치 버전의 동작**은 별도로 확인해야 한다. 아래 URL은 내부 Claude가 접근 가능할 때만 조회하고, 외부 인터넷이 막혀 있으면 사내 설치 문서/기능 테스트로 대체한다.

| 근거 | URL | 설계에 미친 영향 |
|---|---|---|
| Grafana Data Links | https://grafana.com/docs/grafana/latest/visualizations/panels-visualizations/configure-data-links/ | 시각화마다 클릭/one-click 다름; 새 탭 옵션은 실제 테스트 |
| Grafana dashboard links | https://grafana.com/docs/grafana/latest/visualizations/dashboards/build-dashboards/manage-dashboard-links/ | 패널/대시보드 링크 역할 구분 |
| Grafana provisioning | https://grafana.com/docs/grafana/latest/administration/provisioning/ | UI 변경 덮어쓰기/소유권 검토 |
| OpenSearch terms | https://docs.opensearch.org/latest/aggregations/bucket/terms/ | TOP N 누락/오차 고려 |
| OpenSearch composite | https://docs.opensearch.org/latest/aggregations/bucket/composite/ | 전체 버킷 순회 시 after_key·성능 검토 |
| OpenSearch cardinality | https://docs.opensearch.org/latest/aggregations/metric/cardinality/ | 고유 수 근사·정확도 비용 |
| Confluence Cloud REST v2 | https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-page/ | 페이지 parent/space/version 검토 |
| Confluence Data Center REST | https://developer.atlassian.com/server/confluence/rest/v900/api-group-content-resource/ | Cloud와 API 구조 혼동 금지 |
| React StrictMode | https://react.dev/reference/react/StrictMode | 개발 환경 effect/렌더 재실행, 클릭 이벤트 중복 주의 |
| React useEffect | https://react.dev/reference/react/useEffect | 렌더·effect와 사용자 행동 구분 |
| OpenTelemetry JS | https://opentelemetry.io/docs/languages/js/ | 브라우저 계측 채택 강제 금지, 지원 상태 확인 |

## 사내 확인 필수

실제 Java/Kotlin 서비스 이벤트 의미·중복·로그 수집 경로, OpenSearch 필드 매핑·버전·인덱스 범위, Grafana 버전·플러그인·프로비저닝·권한, Confluence Cloud/DC·페이지 트리·SSO, 운영자 업무 시나리오, React Router·개인정보 정책·미래 계측 방법. 확인 전 기능 호환·수치 정확성·링크 동작은 `NOT_TESTED`.

## 검증 표현 금지

'공식 문서에서 지원' → '우리 사내에서 정상 작동', '합성 테스트 통과' → '실제 로그 정확', '페이지 생성 API 200' → '운영자가 문서 접근 가능', 'React 자동계측 설치' → '검색 행동 퍼널 완성'이라는 도약 금지.

## v5.2 계층 자동화 공식 출처
- Confluence Cloud Page API: https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-page/ (`parentId`, 페이지 버전)
- Confluence Cloud move API: https://developer.atlassian.com/cloud/confluence/rest/v1/api-group-content---children-and-descendants/
- Confluence Data Center content API: https://developer.atlassian.com/server/confluence/rest/v900/api-group-content-resource/ (`ancestors`, 페이지 버전)
- Grafana dashboard folders: https://grafana.com/docs/grafana/latest/visualizations/dashboards/manage-dashboards/
- Grafana folder permissions: https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/folder-access-control/
**미검증:** 사내 Cloud/Data Center 여부, Confluence 페이지 생성 권한, Grafana UID/패널 실제 목록, Claude 연결 도구, 주기 실행 가능 여부. 검증 전 실제 자동 게시 성공을 주장하지 않는다.
